from xiaohongshu import get_xiaohongshu_note

# 导出函数，使其对Dify可见
__all__ = ["get_xiaohongshu_note"]